<?php require_once('config.inc.php');  ?>
<?php
session_destroy();
?>
<html>
<body>
<h1>Destroy SimpleDB Session Keys</h1>
Keys destroyed

<p><a href=index.php>Return to Menu</a>
</FORM>
<?php printsource(__FILE__); ?>
Copyright &copy; 2010, Rich Helms.  All rights reserved.
<br><a href=http://webmasterinresidence.ca/simpledb/>http://webmasterinresidence.ca/simpledb/</a>
<br><i>Amazon SimpleDB Developer Guide</i> by Prabhakar Chaganti, Rich Helms <a target=_blank href="http://www.packtpub.com/amazon-simpledb-database-developer-guide/">Packt Publishing Ltd</a>

</body>
</html>