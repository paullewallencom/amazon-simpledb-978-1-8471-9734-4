<?php require_once('config.inc.php');  ?>
<html>
<body>
<h1>Include Source Files</h1>
<a href=index.php>Return to Menu</a><p>
<?php printsource('config.inc.php'); ?>
<p>
<?php printsource('sdb.php'); ?>
Copyright &copy; 2010, Rich Helms.  All rights reserved.
<br><a href=http://webmasterinresidence.ca/simpledb/>http://webmasterinresidence.ca/simpledb/</a>
<br><i>Amazon SimpleDB Developer Guide</i> by Prabhakar Chaganti, Rich Helms <a target=_blank href="http://www.packtpub.com/amazon-simpledb-database-developer-guide/">Packt Publishing Ltd</a>

</body>
</html>
